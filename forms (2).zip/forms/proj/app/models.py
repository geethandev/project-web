from django.contrib.auth.models import AbstractUser
from django.db import models

# Create your models here.
class modelinfo (models.Model):
     first_name = models.CharField(max_length=50)
     last_name = models.CharField(max_length=50)
     father_name = models.CharField(max_length=255)
     phone_number=models.IntegerField()
     address=models.CharField(max_length=50)
     educational_qul=models.CharField(max_length=70)
     work_exprence=models.IntegerField()
     gender = models.CharField(max_length=50)

