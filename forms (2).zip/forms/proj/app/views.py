from . import models
from .forms import studinfo
from .models import modelinfo
from django.shortcuts import render

def view (request):
    context = {}
    context['form'] = studinfo()
    if request.method == 'POST':

        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        
        gender = request.POST['gender']


        a = models.modelinfo(gender=gender,first_name=first_name,last_name=last_name,age=age)
        a.save()
    return render(request, "h1.html", context)



def rec(request):
    query = modelinfo.objects.all()
    return render(request, "h2.html", {'BB': query})