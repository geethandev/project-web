from django import forms




class studinfo(forms.Form):
	first_name=forms.CharField(max_length=50)
	last_name = forms.CharField(max_length=50)
	father_name = forms.CharField(max_length=255)
	phone_number = forms.IntegerField()
	address = forms.CharField(max_length=50)
	educational_qul = forms.CharField(max_length=70)
	work_exprence = forms.IntegerField()
	gender=forms.CharField(max_length=50)

class meta:
	model=studinfo
